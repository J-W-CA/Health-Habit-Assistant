//
//  File.swift
//  WeeklyHabitTracker
//
//  Created by Robert Parsons on 4/27/20.
//  Copyright © 2020 Robert Parsons. All rights reserved.
//

import Foundation

enum Section {
    case main
}
