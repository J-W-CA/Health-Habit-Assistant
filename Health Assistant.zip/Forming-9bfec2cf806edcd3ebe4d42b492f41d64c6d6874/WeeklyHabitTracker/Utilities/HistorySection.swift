//
//  HistorySection.swift
//  WeeklyHabitTracker
//
//  Created by Jason Wang on 6/13/20.
//  Copyright © 2020 Jason Wang. All rights reserved.
//

import Foundation

enum HistorySection {
    case activeHabits
    case finishedHabits
}
